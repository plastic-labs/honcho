// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { AbstractPage } from "./core.mjs";
export class Page extends AbstractPage {
    constructor(client, response, body, options) {
        super(client, response, body, options);
        this.total = body.total || 0;
        this.items = body.items || [];
        this.page = body.page || 0;
        this.size = body.size || 0;
        this.pages = body.pages || 0;
    }
    getPaginatedItems() {
        return this.items ?? [];
    }
    // @deprecated Please use `nextPageInfo()` instead
    nextPageParams() {
        const info = this.nextPageInfo();
        if (!info)
            return null;
        if ('params' in info)
            return info.params;
        const params = Object.fromEntries(info.url.searchParams);
        if (!Object.keys(params).length)
            return null;
        return params;
    }
    nextPageInfo() {
        const currentPage = this.page;
        if (currentPage >= this.pages) {
            return null;
        }
        return { params: { page: currentPage + 1 } };
    }
}
//# sourceMappingURL=pagination.mjs.map