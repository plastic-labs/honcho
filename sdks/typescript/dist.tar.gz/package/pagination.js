"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Page = void 0;
const core_1 = require("./core.js");
class Page extends core_1.AbstractPage {
    constructor(client, response, body, options) {
        super(client, response, body, options);
        this.total = body.total || 0;
        this.items = body.items || [];
        this.page = body.page || 0;
        this.size = body.size || 0;
        this.pages = body.pages || 0;
    }
    getPaginatedItems() {
        return this.items ?? [];
    }
    // @deprecated Please use `nextPageInfo()` instead
    nextPageParams() {
        const info = this.nextPageInfo();
        if (!info)
            return null;
        if ('params' in info)
            return info.params;
        const params = Object.fromEntries(info.url.searchParams);
        if (!Object.keys(params).length)
            return null;
        return params;
    }
    nextPageInfo() {
        const currentPage = this.page;
        if (currentPage >= this.pages) {
            return null;
        }
        return { params: { page: currentPage + 1 } };
    }
}
exports.Page = Page;
//# sourceMappingURL=pagination.js.map