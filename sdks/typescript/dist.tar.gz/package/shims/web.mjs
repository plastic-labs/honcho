import * as types from "../_shims/web-types.mjs";
import { setShims } from "../_shims/registry.mjs";
import { getRuntime } from "../_shims/web-runtime.mjs";
setShims(getRuntime({ manuallyImported: true }));
//# sourceMappingURL=web.mjs.map