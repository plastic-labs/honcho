import * as types from "../_shims/node-types.mjs";
import { setShims } from "../_shims/registry.mjs";
import { getRuntime } from "../_shims/node-runtime.mjs";
setShims(getRuntime());
//# sourceMappingURL=node.mjs.map