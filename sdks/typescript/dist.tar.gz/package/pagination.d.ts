import { AbstractPage, Response, APIClient, FinalRequestOptions, PageInfo } from "./core.js";
export interface PageResponse<Item> {
    total: number;
    items: Array<Item>;
    page: number;
    size: number;
    pages: number;
}
export interface PageParams {
    /**
     * The page number
     */
    page?: number;
    /**
     * The number of items in a page
     */
    size?: number;
}
export declare class Page<Item> extends AbstractPage<Item> implements PageResponse<Item> {
    total: number;
    items: Array<Item>;
    page: number;
    size: number;
    pages: number;
    constructor(client: APIClient, response: Response, body: PageResponse<Item>, options: FinalRequestOptions);
    getPaginatedItems(): Item[];
    nextPageParams(): Partial<PageParams> | null;
    nextPageInfo(): PageInfo | null;
}
//# sourceMappingURL=pagination.d.ts.map