import { type Shims } from "./registry.js";
export declare function getRuntime({ manuallyImported }?: {
    manuallyImported?: boolean;
}): Shims;
//# sourceMappingURL=web-runtime.d.ts.map