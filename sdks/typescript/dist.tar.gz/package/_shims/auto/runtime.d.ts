/**
 * Disclaimer: modules in _shims aren't intended to be imported by SDK users.
 */
export * from "../web-runtime.js";
//# sourceMappingURL=runtime.d.ts.map