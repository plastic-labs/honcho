/**
 * Disclaimer: modules in _shims aren't intended to be imported by SDK users.
 */
export declare class MultipartBody {
    body: any;
    constructor(body: any);
    get [Symbol.toStringTag](): string;
}
//# sourceMappingURL=MultipartBody.d.ts.map