import { type Shims } from "./registry.js";
export declare function getRuntime(): Shims;
//# sourceMappingURL=node-runtime.d.ts.map