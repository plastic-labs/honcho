export declare const VERSION = "1.5.1";
//# sourceMappingURL=version.d.ts.map