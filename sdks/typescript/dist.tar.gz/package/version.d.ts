export declare const VERSION = "1.5.0";
//# sourceMappingURL=version.d.ts.map