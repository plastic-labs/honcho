"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.VERSION = void 0;
exports.VERSION = '1.5.0'; // x-release-please-version
//# sourceMappingURL=version.js.map