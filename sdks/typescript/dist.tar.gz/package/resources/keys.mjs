// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../resource.mjs";
import { isRequestOptions } from "../core.mjs";
export class Keys extends APIResource {
    create(params = {}, options) {
        if (isRequestOptions(params)) {
            return this.create({}, params);
        }
        const { expires_at, peer_id, session_id, workspace_id } = params;
        return this._client.post('/v2/keys', {
            query: { expires_at, peer_id, session_id, workspace_id },
            ...options,
        });
    }
}
//# sourceMappingURL=keys.mjs.map