import { APIResource } from "../resource.js";
import * as Core from "../core.js";
export declare class Keys extends APIResource {
    /**
     * Create a new Key
     */
    create(params?: KeyCreateParams, options?: Core.RequestOptions): Core.APIPromise<unknown>;
    create(options?: Core.RequestOptions): Core.APIPromise<unknown>;
}
export type KeyCreateResponse = unknown;
export interface KeyCreateParams {
    expires_at?: string | null;
    /**
     * ID of the peer to scope the key to
     */
    peer_id?: string | null;
    /**
     * ID of the session to scope the key to
     */
    session_id?: string | null;
    /**
     * ID of the workspace to scope the key to
     */
    workspace_id?: string | null;
}
export declare namespace Keys {
    export { type KeyCreateResponse as KeyCreateResponse, type KeyCreateParams as KeyCreateParams };
}
//# sourceMappingURL=keys.d.ts.map