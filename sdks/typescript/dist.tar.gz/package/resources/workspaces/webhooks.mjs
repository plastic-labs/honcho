// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../../resource.mjs";
import { isRequestOptions } from "../../core.mjs";
import { Page } from "../../pagination.mjs";
export class Webhooks extends APIResource {
    list(workspaceId, query = {}, options) {
        if (isRequestOptions(query)) {
            return this.list(workspaceId, {}, query);
        }
        return this._client.getAPIList(`/v2/workspaces/${workspaceId}/webhooks`, WebhookEndpointsPage, {
            query,
            ...options,
        });
    }
    /**
     * Delete a specific webhook endpoint.
     */
    delete(workspaceId, endpointId, options) {
        return this._client.delete(`/v2/workspaces/${workspaceId}/webhooks/${endpointId}`, options);
    }
    /**
     * Get or create a webhook endpoint URL.
     */
    getOrCreate(workspaceId, body, options) {
        return this._client.post(`/v2/workspaces/${workspaceId}/webhooks`, { body, ...options });
    }
    /**
     * Test publishing a webhook event.
     */
    testEmit(workspaceId, options) {
        return this._client.get(`/v2/workspaces/${workspaceId}/webhooks/test`, options);
    }
}
export class WebhookEndpointsPage extends Page {
}
Webhooks.WebhookEndpointsPage = WebhookEndpointsPage;
//# sourceMappingURL=webhooks.mjs.map