"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Workspaces = exports.WorkspacesPage = exports.Webhooks = exports.WebhookEndpointsPage = exports.Sessions = exports.SessionsPage = exports.Peers = exports.PeersPage = void 0;
var index_1 = require("./peers/index.js");
Object.defineProperty(exports, "PeersPage", { enumerable: true, get: function () { return index_1.PeersPage; } });
Object.defineProperty(exports, "Peers", { enumerable: true, get: function () { return index_1.Peers; } });
var index_2 = require("./sessions/index.js");
Object.defineProperty(exports, "SessionsPage", { enumerable: true, get: function () { return index_2.SessionsPage; } });
Object.defineProperty(exports, "Sessions", { enumerable: true, get: function () { return index_2.Sessions; } });
var webhooks_1 = require("./webhooks.js");
Object.defineProperty(exports, "WebhookEndpointsPage", { enumerable: true, get: function () { return webhooks_1.WebhookEndpointsPage; } });
Object.defineProperty(exports, "Webhooks", { enumerable: true, get: function () { return webhooks_1.Webhooks; } });
var workspaces_1 = require("./workspaces.js");
Object.defineProperty(exports, "WorkspacesPage", { enumerable: true, get: function () { return workspaces_1.WorkspacesPage; } });
Object.defineProperty(exports, "Workspaces", { enumerable: true, get: function () { return workspaces_1.Workspaces; } });
//# sourceMappingURL=index.js.map