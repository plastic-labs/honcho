"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.WorkspacesPage = exports.Workspaces = void 0;
const resource_1 = require("../../resource.js");
const core_1 = require("../../core.js");
const WebhooksAPI = __importStar(require("./webhooks.js"));
const webhooks_1 = require("./webhooks.js");
const PeersAPI = __importStar(require("./peers/peers.js"));
const peers_1 = require("./peers/peers.js");
const SessionsAPI = __importStar(require("./sessions/sessions.js"));
const sessions_1 = require("./sessions/sessions.js");
const pagination_1 = require("../../pagination.js");
class Workspaces extends resource_1.APIResource {
    constructor() {
        super(...arguments);
        this.peers = new PeersAPI.Peers(this._client);
        this.sessions = new SessionsAPI.Sessions(this._client);
        this.webhooks = new WebhooksAPI.Webhooks(this._client);
    }
    /**
     * Update a Workspace
     */
    update(workspaceId, body, options) {
        return this._client.put(`/v2/workspaces/${workspaceId}`, { body, ...options });
    }
    list(params = {}, options) {
        if ((0, core_1.isRequestOptions)(params)) {
            return this.list({}, params);
        }
        const { page, size, ...body } = params;
        return this._client.getAPIList('/v2/workspaces/list', WorkspacesPage, {
            query: { page, size },
            body,
            method: 'post',
            ...options,
        });
    }
    /**
     * Delete a Workspace
     */
    delete(workspaceId, options) {
        return this._client.delete(`/v2/workspaces/${workspaceId}`, options);
    }
    deriverStatus(workspaceId, query = {}, options) {
        if ((0, core_1.isRequestOptions)(query)) {
            return this.deriverStatus(workspaceId, {}, query);
        }
        return this._client.get(`/v2/workspaces/${workspaceId}/deriver/status`, { query, ...options });
    }
    /**
     * Get a Workspace by ID.
     *
     * If workspace_id is provided as a query parameter, it uses that (must match JWT
     * workspace_id). Otherwise, it uses the workspace_id from the JWT.
     */
    getOrCreate(body, options) {
        return this._client.post('/v2/workspaces', { body, ...options });
    }
    /**
     * Search a Workspace
     */
    search(workspaceId, body, options) {
        return this._client.post(`/v2/workspaces/${workspaceId}/search`, { body, ...options });
    }
}
exports.Workspaces = Workspaces;
class WorkspacesPage extends pagination_1.Page {
}
exports.WorkspacesPage = WorkspacesPage;
Workspaces.WorkspacesPage = WorkspacesPage;
Workspaces.Peers = peers_1.Peers;
Workspaces.PeersPage = peers_1.PeersPage;
Workspaces.Sessions = sessions_1.Sessions;
Workspaces.SessionsPage = sessions_1.SessionsPage;
Workspaces.Webhooks = webhooks_1.Webhooks;
Workspaces.WebhookEndpointsPage = webhooks_1.WebhookEndpointsPage;
//# sourceMappingURL=workspaces.js.map