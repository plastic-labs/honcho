import { APIResource } from "../../../resource.js";
import * as Core from "../../../core.js";
import * as SessionsSessionsAPI from "../sessions/sessions.js";
import { SessionsPage } from "../sessions/sessions.js";
import { type PageParams } from "../../../pagination.js";
export declare class Sessions extends APIResource {
    /**
     * Get All Sessions for a Peer
     */
    list(workspaceId: string, peerId: string, params?: SessionListParams, options?: Core.RequestOptions): Core.PagePromise<SessionsPage, SessionsSessionsAPI.Session>;
    list(workspaceId: string, peerId: string, options?: Core.RequestOptions): Core.PagePromise<SessionsPage, SessionsSessionsAPI.Session>;
}
export interface SessionListParams extends PageParams {
    /**
     * Body param:
     */
    filters?: {
        [key: string]: unknown;
    } | null;
}
export declare namespace Sessions {
    export { type SessionListParams as SessionListParams };
}
export { SessionsPage };
//# sourceMappingURL=sessions.d.ts.map