"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.SessionsPage = exports.Sessions = void 0;
const resource_1 = require("../../../resource.js");
const core_1 = require("../../../core.js");
const sessions_1 = require("../sessions/sessions.js");
Object.defineProperty(exports, "SessionsPage", { enumerable: true, get: function () { return sessions_1.SessionsPage; } });
class Sessions extends resource_1.APIResource {
    list(workspaceId, peerId, params = {}, options) {
        if ((0, core_1.isRequestOptions)(params)) {
            return this.list(workspaceId, peerId, {}, params);
        }
        const { page, size, ...body } = params;
        return this._client.getAPIList(`/v2/workspaces/${workspaceId}/peers/${peerId}/sessions`, sessions_1.SessionsPage, {
            query: { page, size },
            body,
            method: 'post',
            ...options,
        });
    }
}
exports.Sessions = Sessions;
//# sourceMappingURL=sessions.js.map