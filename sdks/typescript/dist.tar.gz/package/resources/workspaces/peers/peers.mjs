// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../../../resource.mjs";
import { isRequestOptions } from "../../../core.mjs";
import * as SessionsAPI from "./sessions.mjs";
import { Sessions } from "./sessions.mjs";
import { Page } from "../../../pagination.mjs";
export class Peers extends APIResource {
    constructor() {
        super(...arguments);
        this.sessions = new SessionsAPI.Sessions(this._client);
    }
    /**
     * Update a Peer's name and/or metadata
     */
    update(workspaceId, peerId, body, options) {
        return this._client.put(`/v2/workspaces/${workspaceId}/peers/${peerId}`, { body, ...options });
    }
    list(workspaceId, params = {}, options) {
        if (isRequestOptions(params)) {
            return this.list(workspaceId, {}, params);
        }
        const { page, size, ...body } = params;
        return this._client.getAPIList(`/v2/workspaces/${workspaceId}/peers/list`, PeersPage, {
            query: { page, size },
            body,
            method: 'post',
            ...options,
        });
    }
    card(workspaceId, peerId, query = {}, options) {
        if (isRequestOptions(query)) {
            return this.card(workspaceId, peerId, {}, query);
        }
        return this._client.get(`/v2/workspaces/${workspaceId}/peers/${peerId}/card`, { query, ...options });
    }
    /**
     * Chat
     */
    chat(workspaceId, peerId, body, options) {
        return this._client.post(`/v2/workspaces/${workspaceId}/peers/${peerId}/chat`, { body, ...options });
    }
    /**
     * Get a Peer by ID
     *
     * If peer_id is provided as a query parameter, it uses that (must match JWT
     * workspace_id). Otherwise, it uses the peer_id from the JWT.
     */
    getOrCreate(workspaceId, body, options) {
        return this._client.post(`/v2/workspaces/${workspaceId}/peers`, { body, ...options });
    }
    /**
     * Search a Peer
     */
    search(workspaceId, peerId, body, options) {
        return this._client.post(`/v2/workspaces/${workspaceId}/peers/${peerId}/search`, { body, ...options });
    }
    /**
     * Set a peer card for a specific peer relationship.
     *
     * Sets the peer card that the observer peer has for the target peer. If no target
     * is specified, sets the observer's own peer card.
     */
    setCard(workspaceId, peerId, params, options) {
        const { target, ...body } = params;
        return this._client.put(`/v2/workspaces/${workspaceId}/peers/${peerId}/card`, {
            query: { target },
            body,
            ...options,
        });
    }
    /**
     * Get a peer's working representation for a session.
     *
     * If a session_id is provided in the body, we get the working representation of
     * the peer in that session. If a target is provided, we get the representation of
     * the target from the perspective of the peer. If no target is provided, we get
     * the omniscient Honcho representation of the peer.
     */
    workingRepresentation(workspaceId, peerId, body, options) {
        return this._client.post(`/v2/workspaces/${workspaceId}/peers/${peerId}/representation`, {
            body,
            ...options,
        });
    }
}
export class PeersPage extends Page {
}
Peers.PeersPage = PeersPage;
Peers.Sessions = Sessions;
//# sourceMappingURL=peers.mjs.map