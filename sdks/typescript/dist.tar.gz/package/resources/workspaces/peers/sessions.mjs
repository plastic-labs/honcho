// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../../../resource.mjs";
import { isRequestOptions } from "../../../core.mjs";
import { SessionsPage } from "../sessions/sessions.mjs";
export class Sessions extends APIResource {
    list(workspaceId, peerId, params = {}, options) {
        if (isRequestOptions(params)) {
            return this.list(workspaceId, peerId, {}, params);
        }
        const { page, size, ...body } = params;
        return this._client.getAPIList(`/v2/workspaces/${workspaceId}/peers/${peerId}/sessions`, SessionsPage, {
            query: { page, size },
            body,
            method: 'post',
            ...options,
        });
    }
}
export { SessionsPage };
//# sourceMappingURL=sessions.mjs.map