"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PeersPage = exports.Peers = void 0;
const resource_1 = require("../../../resource.js");
const core_1 = require("../../../core.js");
const SessionsAPI = __importStar(require("./sessions.js"));
const sessions_1 = require("./sessions.js");
const pagination_1 = require("../../../pagination.js");
class Peers extends resource_1.APIResource {
    constructor() {
        super(...arguments);
        this.sessions = new SessionsAPI.Sessions(this._client);
    }
    /**
     * Update a Peer's name and/or metadata
     */
    update(workspaceId, peerId, body, options) {
        return this._client.put(`/v2/workspaces/${workspaceId}/peers/${peerId}`, { body, ...options });
    }
    list(workspaceId, params = {}, options) {
        if ((0, core_1.isRequestOptions)(params)) {
            return this.list(workspaceId, {}, params);
        }
        const { page, size, ...body } = params;
        return this._client.getAPIList(`/v2/workspaces/${workspaceId}/peers/list`, PeersPage, {
            query: { page, size },
            body,
            method: 'post',
            ...options,
        });
    }
    card(workspaceId, peerId, query = {}, options) {
        if ((0, core_1.isRequestOptions)(query)) {
            return this.card(workspaceId, peerId, {}, query);
        }
        return this._client.get(`/v2/workspaces/${workspaceId}/peers/${peerId}/card`, { query, ...options });
    }
    /**
     * Chat
     */
    chat(workspaceId, peerId, body, options) {
        return this._client.post(`/v2/workspaces/${workspaceId}/peers/${peerId}/chat`, { body, ...options });
    }
    /**
     * Get a Peer by ID
     *
     * If peer_id is provided as a query parameter, it uses that (must match JWT
     * workspace_id). Otherwise, it uses the peer_id from the JWT.
     */
    getOrCreate(workspaceId, body, options) {
        return this._client.post(`/v2/workspaces/${workspaceId}/peers`, { body, ...options });
    }
    /**
     * Search a Peer
     */
    search(workspaceId, peerId, body, options) {
        return this._client.post(`/v2/workspaces/${workspaceId}/peers/${peerId}/search`, { body, ...options });
    }
    /**
     * Get a peer's working representation for a session.
     *
     * If a session_id is provided in the body, we get the working representation of
     * the peer in that session. If a target is provided, we get the representation of
     * the target from the perspective of the peer. If no target is provided, we get
     * the omniscient Honcho representation of the peer.
     */
    workingRepresentation(workspaceId, peerId, body, options) {
        return this._client.post(`/v2/workspaces/${workspaceId}/peers/${peerId}/representation`, {
            body,
            ...options,
        });
    }
}
exports.Peers = Peers;
class PeersPage extends pagination_1.Page {
}
exports.PeersPage = PeersPage;
Peers.PeersPage = PeersPage;
Peers.Sessions = sessions_1.Sessions;
//# sourceMappingURL=peers.js.map