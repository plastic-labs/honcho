import { APIResource } from "../../resource.js";
import * as Core from "../../core.js";
import { Page, type PageParams } from "../../pagination.js";
export declare class Webhooks extends APIResource {
    /**
     * List all webhook endpoints, optionally filtered by workspace.
     */
    list(workspaceId: string, query?: WebhookListParams, options?: Core.RequestOptions): Core.PagePromise<WebhookEndpointsPage, WebhookEndpoint>;
    list(workspaceId: string, options?: Core.RequestOptions): Core.PagePromise<WebhookEndpointsPage, WebhookEndpoint>;
    /**
     * Delete a specific webhook endpoint.
     */
    delete(workspaceId: string, endpointId: string, options?: Core.RequestOptions): Core.APIPromise<unknown>;
    /**
     * Get or create a webhook endpoint URL.
     */
    getOrCreate(workspaceId: string, body: WebhookGetOrCreateParams, options?: Core.RequestOptions): Core.APIPromise<WebhookEndpoint>;
    /**
     * Test publishing a webhook event.
     */
    testEmit(workspaceId: string, options?: Core.RequestOptions): Core.APIPromise<unknown>;
}
export declare class WebhookEndpointsPage extends Page<WebhookEndpoint> {
}
export interface WebhookEndpoint {
    id: string;
    created_at: string;
    url: string;
    workspace_id: string | null;
}
export type WebhookDeleteResponse = unknown;
export type WebhookTestEmitResponse = unknown;
export interface WebhookListParams extends PageParams {
}
export interface WebhookGetOrCreateParams {
    url: string;
}
export declare namespace Webhooks {
    export { type WebhookEndpoint as WebhookEndpoint, type WebhookDeleteResponse as WebhookDeleteResponse, type WebhookTestEmitResponse as WebhookTestEmitResponse, WebhookEndpointsPage as WebhookEndpointsPage, type WebhookListParams as WebhookListParams, type WebhookGetOrCreateParams as WebhookGetOrCreateParams, };
}
//# sourceMappingURL=webhooks.d.ts.map