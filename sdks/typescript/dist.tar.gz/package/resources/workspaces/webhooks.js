"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.WebhookEndpointsPage = exports.Webhooks = void 0;
const resource_1 = require("../../resource.js");
const core_1 = require("../../core.js");
const pagination_1 = require("../../pagination.js");
class Webhooks extends resource_1.APIResource {
    list(workspaceId, query = {}, options) {
        if ((0, core_1.isRequestOptions)(query)) {
            return this.list(workspaceId, {}, query);
        }
        return this._client.getAPIList(`/v2/workspaces/${workspaceId}/webhooks`, WebhookEndpointsPage, {
            query,
            ...options,
        });
    }
    /**
     * Delete a specific webhook endpoint.
     */
    delete(workspaceId, endpointId, options) {
        return this._client.delete(`/v2/workspaces/${workspaceId}/webhooks/${endpointId}`, options);
    }
    /**
     * Get or create a webhook endpoint URL.
     */
    getOrCreate(workspaceId, body, options) {
        return this._client.post(`/v2/workspaces/${workspaceId}/webhooks`, { body, ...options });
    }
    /**
     * Test publishing a webhook event.
     */
    testEmit(workspaceId, options) {
        return this._client.get(`/v2/workspaces/${workspaceId}/webhooks/test`, options);
    }
}
exports.Webhooks = Webhooks;
class WebhookEndpointsPage extends pagination_1.Page {
}
exports.WebhookEndpointsPage = WebhookEndpointsPage;
Webhooks.WebhookEndpointsPage = WebhookEndpointsPage;
//# sourceMappingURL=webhooks.js.map