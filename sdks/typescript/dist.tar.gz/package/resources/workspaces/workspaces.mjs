// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../../resource.mjs";
import { isRequestOptions } from "../../core.mjs";
import * as WebhooksAPI from "./webhooks.mjs";
import { WebhookEndpointsPage, Webhooks, } from "./webhooks.mjs";
import * as PeersAPI from "./peers/peers.mjs";
import { Peers, PeersPage, } from "./peers/peers.mjs";
import * as SessionsAPI from "./sessions/sessions.mjs";
import { Sessions as SessionsAPISessions, SessionsPage, } from "./sessions/sessions.mjs";
import { Page } from "../../pagination.mjs";
export class Workspaces extends APIResource {
    constructor() {
        super(...arguments);
        this.peers = new PeersAPI.Peers(this._client);
        this.sessions = new SessionsAPI.Sessions(this._client);
        this.webhooks = new WebhooksAPI.Webhooks(this._client);
    }
    /**
     * Update a Workspace
     */
    update(workspaceId, body, options) {
        return this._client.put(`/v2/workspaces/${workspaceId}`, { body, ...options });
    }
    list(params = {}, options) {
        if (isRequestOptions(params)) {
            return this.list({}, params);
        }
        const { page, size, ...body } = params;
        return this._client.getAPIList('/v2/workspaces/list', WorkspacesPage, {
            query: { page, size },
            body,
            method: 'post',
            ...options,
        });
    }
    /**
     * Delete a Workspace
     */
    delete(workspaceId, options) {
        return this._client.delete(`/v2/workspaces/${workspaceId}`, options);
    }
    deriverStatus(workspaceId, query = {}, options) {
        if (isRequestOptions(query)) {
            return this.deriverStatus(workspaceId, {}, query);
        }
        return this._client.get(`/v2/workspaces/${workspaceId}/deriver/status`, { query, ...options });
    }
    /**
     * Get a Workspace by ID.
     *
     * If workspace_id is provided as a query parameter, it uses that (must match JWT
     * workspace_id). Otherwise, it uses the workspace_id from the JWT.
     */
    getOrCreate(body, options) {
        return this._client.post('/v2/workspaces', { body, ...options });
    }
    /**
     * Search a Workspace
     */
    search(workspaceId, body, options) {
        return this._client.post(`/v2/workspaces/${workspaceId}/search`, { body, ...options });
    }
    /**
     * Manually trigger a dream task immediately for a specific collection.
     *
     * This endpoint bypasses all automatic dream conditions (document threshold,
     * minimum hours between dreams) and executes the dream task immediately without
     * delay.
     */
    triggerDream(workspaceId, body, options) {
        return this._client.post(`/v2/workspaces/${workspaceId}/trigger_dream`, {
            body,
            ...options,
            headers: { Accept: '*/*', ...options?.headers },
        });
    }
}
export class WorkspacesPage extends Page {
}
Workspaces.WorkspacesPage = WorkspacesPage;
Workspaces.Peers = Peers;
Workspaces.PeersPage = PeersPage;
Workspaces.Sessions = SessionsAPISessions;
Workspaces.SessionsPage = SessionsPage;
Workspaces.Webhooks = Webhooks;
Workspaces.WebhookEndpointsPage = WebhookEndpointsPage;
//# sourceMappingURL=workspaces.mjs.map