"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.PeersPage = exports.Peers = void 0;
const resource_1 = require("../../../resource.js");
const core_1 = require("../../../core.js");
const peers_1 = require("../peers/peers.js");
Object.defineProperty(exports, "PeersPage", { enumerable: true, get: function () { return peers_1.PeersPage; } });
class Peers extends resource_1.APIResource {
    list(workspaceId, sessionId, query = {}, options) {
        if ((0, core_1.isRequestOptions)(query)) {
            return this.list(workspaceId, sessionId, {}, query);
        }
        return this._client.getAPIList(`/v2/workspaces/${workspaceId}/sessions/${sessionId}/peers`, peers_1.PeersPage, {
            query,
            ...options,
        });
    }
    /**
     * Add peers to a session
     */
    add(workspaceId, sessionId, body, options) {
        return this._client.post(`/v2/workspaces/${workspaceId}/sessions/${sessionId}/peers`, {
            body,
            ...options,
        });
    }
    /**
     * Get the configuration for a peer in a session
     */
    getConfig(workspaceId, sessionId, peerId, options) {
        return this._client.get(`/v2/workspaces/${workspaceId}/sessions/${sessionId}/peers/${peerId}/config`, options);
    }
    /**
     * Remove peers from a session
     */
    remove(workspaceId, sessionId, body, options) {
        return this._client.delete(`/v2/workspaces/${workspaceId}/sessions/${sessionId}/peers`, {
            body,
            ...options,
        });
    }
    /**
     * Set the peers in a session
     */
    set(workspaceId, sessionId, body, options) {
        return this._client.put(`/v2/workspaces/${workspaceId}/sessions/${sessionId}/peers`, {
            body,
            ...options,
        });
    }
    /**
     * Set the configuration for a peer in a session
     */
    setConfig(workspaceId, sessionId, peerId, body, options) {
        return this._client.post(`/v2/workspaces/${workspaceId}/sessions/${sessionId}/peers/${peerId}/config`, {
            body,
            ...options,
        });
    }
}
exports.Peers = Peers;
//# sourceMappingURL=peers.js.map