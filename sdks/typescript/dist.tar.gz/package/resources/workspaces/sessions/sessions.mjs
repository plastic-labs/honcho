// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../../../resource.mjs";
import { isRequestOptions } from "../../../core.mjs";
import * as MessagesAPI from "./messages.mjs";
import { Messages, MessagesPage, } from "./messages.mjs";
import * as PeersAPI from "./peers.mjs";
import { Peers, } from "./peers.mjs";
import { Page } from "../../../pagination.mjs";
export class Sessions extends APIResource {
    constructor() {
        super(...arguments);
        this.messages = new MessagesAPI.Messages(this._client);
        this.peers = new PeersAPI.Peers(this._client);
    }
    /**
     * Update the metadata of a Session
     */
    update(workspaceId, sessionId, body, options) {
        return this._client.put(`/v2/workspaces/${workspaceId}/sessions/${sessionId}`, { body, ...options });
    }
    list(workspaceId, params = {}, options) {
        if (isRequestOptions(params)) {
            return this.list(workspaceId, {}, params);
        }
        const { page, size, ...body } = params;
        return this._client.getAPIList(`/v2/workspaces/${workspaceId}/sessions/list`, SessionsPage, {
            query: { page, size },
            body,
            method: 'post',
            ...options,
        });
    }
    /**
     * Delete a session by marking it as inactive
     */
    delete(workspaceId, sessionId, options) {
        return this._client.delete(`/v2/workspaces/${workspaceId}/sessions/${sessionId}`, options);
    }
    clone(workspaceId, sessionId, query = {}, options) {
        if (isRequestOptions(query)) {
            return this.clone(workspaceId, sessionId, {}, query);
        }
        return this._client.get(`/v2/workspaces/${workspaceId}/sessions/${sessionId}/clone`, {
            query,
            ...options,
        });
    }
    getContext(workspaceId, sessionId, query = {}, options) {
        if (isRequestOptions(query)) {
            return this.getContext(workspaceId, sessionId, {}, query);
        }
        return this._client.get(`/v2/workspaces/${workspaceId}/sessions/${sessionId}/context`, {
            query,
            ...options,
        });
    }
    /**
     * Get a specific session in a workspace.
     *
     * If session_id is provided as a query parameter, it verifies the session is in
     * the workspace. Otherwise, it uses the session_id from the JWT for verification.
     */
    getOrCreate(workspaceId, body, options) {
        return this._client.post(`/v2/workspaces/${workspaceId}/sessions`, { body, ...options });
    }
    /**
     * Search a Session
     */
    search(workspaceId, sessionId, body, options) {
        return this._client.post(`/v2/workspaces/${workspaceId}/sessions/${sessionId}/search`, {
            body,
            ...options,
        });
    }
    /**
     * Get available summaries for a session.
     *
     * Returns both short and long summaries if available, including metadata like the
     * message ID they cover up to, creation timestamp, and token count.
     */
    summaries(workspaceId, sessionId, options) {
        return this._client.get(`/v2/workspaces/${workspaceId}/sessions/${sessionId}/summaries`, options);
    }
}
export class SessionsPage extends Page {
}
Sessions.SessionsPage = SessionsPage;
Sessions.Messages = Messages;
Sessions.MessagesPage = MessagesPage;
Sessions.Peers = Peers;
//# sourceMappingURL=sessions.mjs.map