"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SessionsPage = exports.Sessions = void 0;
const resource_1 = require("../../../resource.js");
const core_1 = require("../../../core.js");
const MessagesAPI = __importStar(require("./messages.js"));
const messages_1 = require("./messages.js");
const PeersAPI = __importStar(require("./peers.js"));
const peers_1 = require("./peers.js");
const pagination_1 = require("../../../pagination.js");
class Sessions extends resource_1.APIResource {
    constructor() {
        super(...arguments);
        this.messages = new MessagesAPI.Messages(this._client);
        this.peers = new PeersAPI.Peers(this._client);
    }
    /**
     * Update the metadata of a Session
     */
    update(workspaceId, sessionId, body, options) {
        return this._client.put(`/v2/workspaces/${workspaceId}/sessions/${sessionId}`, { body, ...options });
    }
    list(workspaceId, params = {}, options) {
        if ((0, core_1.isRequestOptions)(params)) {
            return this.list(workspaceId, {}, params);
        }
        const { page, size, ...body } = params;
        return this._client.getAPIList(`/v2/workspaces/${workspaceId}/sessions/list`, SessionsPage, {
            query: { page, size },
            body,
            method: 'post',
            ...options,
        });
    }
    /**
     * Delete a session and all associated data.
     *
     * The session is marked as inactive immediately and returns 202 Accepted. The
     * actual deletion of all related data (messages, embeddings, documents, etc.)
     * happens asynchronously in the background.
     *
     * This action cannot be undone.
     */
    delete(workspaceId, sessionId, options) {
        return this._client.delete(`/v2/workspaces/${workspaceId}/sessions/${sessionId}`, options);
    }
    clone(workspaceId, sessionId, query = {}, options) {
        if ((0, core_1.isRequestOptions)(query)) {
            return this.clone(workspaceId, sessionId, {}, query);
        }
        return this._client.get(`/v2/workspaces/${workspaceId}/sessions/${sessionId}/clone`, {
            query,
            ...options,
        });
    }
    getContext(workspaceId, sessionId, query = {}, options) {
        if ((0, core_1.isRequestOptions)(query)) {
            return this.getContext(workspaceId, sessionId, {}, query);
        }
        return this._client.get(`/v2/workspaces/${workspaceId}/sessions/${sessionId}/context`, {
            query,
            ...options,
        });
    }
    /**
     * Get a specific session in a workspace.
     *
     * If session_id is provided as a query parameter, it verifies the session is in
     * the workspace. Otherwise, it uses the session_id from the JWT for verification.
     */
    getOrCreate(workspaceId, body, options) {
        return this._client.post(`/v2/workspaces/${workspaceId}/sessions`, { body, ...options });
    }
    /**
     * Search a Session
     */
    search(workspaceId, sessionId, body, options) {
        return this._client.post(`/v2/workspaces/${workspaceId}/sessions/${sessionId}/search`, {
            body,
            ...options,
        });
    }
    /**
     * Get available summaries for a session.
     *
     * Returns both short and long summaries if available, including metadata like the
     * message ID they cover up to, creation timestamp, and token count.
     */
    summaries(workspaceId, sessionId, options) {
        return this._client.get(`/v2/workspaces/${workspaceId}/sessions/${sessionId}/summaries`, options);
    }
}
exports.Sessions = Sessions;
class SessionsPage extends pagination_1.Page {
}
exports.SessionsPage = SessionsPage;
Sessions.SessionsPage = SessionsPage;
Sessions.Messages = messages_1.Messages;
Sessions.MessagesPage = messages_1.MessagesPage;
Sessions.Peers = peers_1.Peers;
//# sourceMappingURL=sessions.js.map