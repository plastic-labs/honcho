// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../../../resource.mjs";
import { isRequestOptions } from "../../../core.mjs";
import { PeersPage } from "../peers/peers.mjs";
export class Peers extends APIResource {
    list(workspaceId, sessionId, query = {}, options) {
        if (isRequestOptions(query)) {
            return this.list(workspaceId, sessionId, {}, query);
        }
        return this._client.getAPIList(`/v2/workspaces/${workspaceId}/sessions/${sessionId}/peers`, PeersPage, {
            query,
            ...options,
        });
    }
    /**
     * Add peers to a session
     */
    add(workspaceId, sessionId, body, options) {
        return this._client.post(`/v2/workspaces/${workspaceId}/sessions/${sessionId}/peers`, {
            body,
            ...options,
        });
    }
    /**
     * Get the configuration for a peer in a session
     */
    getConfig(workspaceId, sessionId, peerId, options) {
        return this._client.get(`/v2/workspaces/${workspaceId}/sessions/${sessionId}/peers/${peerId}/config`, options);
    }
    /**
     * Remove peers from a session
     */
    remove(workspaceId, sessionId, body, options) {
        return this._client.delete(`/v2/workspaces/${workspaceId}/sessions/${sessionId}/peers`, {
            body,
            ...options,
        });
    }
    /**
     * Set the peers in a session
     */
    set(workspaceId, sessionId, body, options) {
        return this._client.put(`/v2/workspaces/${workspaceId}/sessions/${sessionId}/peers`, {
            body,
            ...options,
        });
    }
    /**
     * Set the configuration for a peer in a session
     */
    setConfig(workspaceId, sessionId, peerId, body, options) {
        return this._client.post(`/v2/workspaces/${workspaceId}/sessions/${sessionId}/peers/${peerId}/config`, {
            body,
            ...options,
        });
    }
}
export { PeersPage };
//# sourceMappingURL=peers.mjs.map