"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MessagesPage = exports.Messages = void 0;
const resource_1 = require("../../../resource.js");
const core_1 = require("../../../core.js");
const Core = __importStar(require("../../../core.js"));
const pagination_1 = require("../../../pagination.js");
class Messages extends resource_1.APIResource {
    /**
     * Create messages for a session with JSON data (original functionality).
     */
    create(workspaceId, sessionId, body, options) {
        return this._client.post(`/v2/workspaces/${workspaceId}/sessions/${sessionId}/messages/`, {
            body,
            ...options,
        });
    }
    /**
     * Get a Message by ID
     */
    retrieve(workspaceId, sessionId, messageId, options) {
        return this._client.get(`/v2/workspaces/${workspaceId}/sessions/${sessionId}/messages/${messageId}`, options);
    }
    /**
     * Update the metadata of a Message
     */
    update(workspaceId, sessionId, messageId, body, options) {
        return this._client.put(`/v2/workspaces/${workspaceId}/sessions/${sessionId}/messages/${messageId}`, {
            body,
            ...options,
        });
    }
    list(workspaceId, sessionId, params = {}, options) {
        if ((0, core_1.isRequestOptions)(params)) {
            return this.list(workspaceId, sessionId, {}, params);
        }
        const { page, reverse, size, ...body } = params;
        return this._client.getAPIList(`/v2/workspaces/${workspaceId}/sessions/${sessionId}/messages/list`, MessagesPage, { query: { page, reverse, size }, body, method: 'post', ...options });
    }
    /**
     * Create messages from uploaded files. Files are converted to text and split into
     * multiple messages.
     */
    upload(workspaceId, sessionId, body, options) {
        return this._client.post(`/v2/workspaces/${workspaceId}/sessions/${sessionId}/messages/upload`, Core.multipartFormRequestOptions({ body, ...options }));
    }
}
exports.Messages = Messages;
class MessagesPage extends pagination_1.Page {
}
exports.MessagesPage = MessagesPage;
Messages.MessagesPage = MessagesPage;
//# sourceMappingURL=messages.js.map