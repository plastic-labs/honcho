// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../../../resource.mjs";
import { isRequestOptions } from "../../../core.mjs";
import * as Core from "../../../core.mjs";
import { Page } from "../../../pagination.mjs";
export class Messages extends APIResource {
    /**
     * Add new message(s) to a session.
     */
    create(workspaceId, sessionId, body, options) {
        return this._client.post(`/v2/workspaces/${workspaceId}/sessions/${sessionId}/messages/`, {
            body,
            ...options,
        });
    }
    /**
     * Get a Message by ID
     */
    retrieve(workspaceId, sessionId, messageId, options) {
        return this._client.get(`/v2/workspaces/${workspaceId}/sessions/${sessionId}/messages/${messageId}`, options);
    }
    /**
     * Update the metadata of a Message
     */
    update(workspaceId, sessionId, messageId, body, options) {
        return this._client.put(`/v2/workspaces/${workspaceId}/sessions/${sessionId}/messages/${messageId}`, {
            body,
            ...options,
        });
    }
    list(workspaceId, sessionId, params = {}, options) {
        if (isRequestOptions(params)) {
            return this.list(workspaceId, sessionId, {}, params);
        }
        const { page, reverse, size, ...body } = params;
        return this._client.getAPIList(`/v2/workspaces/${workspaceId}/sessions/${sessionId}/messages/list`, MessagesPage, { query: { page, reverse, size }, body, method: 'post', ...options });
    }
    /**
     * Create messages from uploaded files. Files are converted to text and split into
     * multiple messages.
     */
    upload(workspaceId, sessionId, body, options) {
        return this._client.post(`/v2/workspaces/${workspaceId}/sessions/${sessionId}/messages/upload`, Core.multipartFormRequestOptions({ body, ...options }));
    }
}
export class MessagesPage extends Page {
}
Messages.MessagesPage = MessagesPage;
//# sourceMappingURL=messages.mjs.map