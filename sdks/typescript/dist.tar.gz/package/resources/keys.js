"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Keys = void 0;
const resource_1 = require("../resource.js");
const core_1 = require("../core.js");
class Keys extends resource_1.APIResource {
    create(params = {}, options) {
        if ((0, core_1.isRequestOptions)(params)) {
            return this.create({}, params);
        }
        const { expires_at, peer_id, session_id, workspace_id } = params;
        return this._client.post('/v2/keys', {
            query: { expires_at, peer_id, session_id, workspace_id },
            ...options,
        });
    }
}
exports.Keys = Keys;
//# sourceMappingURL=keys.js.map