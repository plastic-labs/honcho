import type { Honcho } from "./index.js";
export declare abstract class APIResource {
    protected _client: Honcho;
    constructor(client: Honcho);
}
//# sourceMappingURL=resource.d.ts.map