export const VERSION = '1.5.0'; // x-release-please-version
//# sourceMappingURL=version.mjs.map