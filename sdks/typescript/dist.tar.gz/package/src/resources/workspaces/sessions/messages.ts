// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

import { APIResource } from "../../../resource.js";
import { isRequestOptions } from "../../../core.js";
import * as Core from "../../../core.js";
import { Page, type PageParams } from "../../../pagination.js";

export class Messages extends APIResource {
  /**
   * Create messages for a session with JSON data (original functionality).
   */
  create(
    workspaceId: string,
    sessionId: string,
    body: MessageCreateParams,
    options?: Core.RequestOptions,
  ): Core.APIPromise<MessageCreateResponse> {
    return this._client.post(`/v2/workspaces/${workspaceId}/sessions/${sessionId}/messages/`, {
      body,
      ...options,
    });
  }

  /**
   * Get a Message by ID
   */
  retrieve(
    workspaceId: string,
    sessionId: string,
    messageId: string,
    options?: Core.RequestOptions,
  ): Core.APIPromise<Message> {
    return this._client.get(
      `/v2/workspaces/${workspaceId}/sessions/${sessionId}/messages/${messageId}`,
      options,
    );
  }

  /**
   * Update the metadata of a Message
   */
  update(
    workspaceId: string,
    sessionId: string,
    messageId: string,
    body: MessageUpdateParams,
    options?: Core.RequestOptions,
  ): Core.APIPromise<Message> {
    return this._client.put(`/v2/workspaces/${workspaceId}/sessions/${sessionId}/messages/${messageId}`, {
      body,
      ...options,
    });
  }

  /**
   * Get all messages for a session
   */
  list(
    workspaceId: string,
    sessionId: string,
    params?: MessageListParams,
    options?: Core.RequestOptions,
  ): Core.PagePromise<MessagesPage, Message>;
  list(
    workspaceId: string,
    sessionId: string,
    options?: Core.RequestOptions,
  ): Core.PagePromise<MessagesPage, Message>;
  list(
    workspaceId: string,
    sessionId: string,
    params: MessageListParams | Core.RequestOptions = {},
    options?: Core.RequestOptions,
  ): Core.PagePromise<MessagesPage, Message> {
    if (isRequestOptions(params)) {
      return this.list(workspaceId, sessionId, {}, params);
    }
    const { page, reverse, size, ...body } = params;
    return this._client.getAPIList(
      `/v2/workspaces/${workspaceId}/sessions/${sessionId}/messages/list`,
      MessagesPage,
      { query: { page, reverse, size }, body, method: 'post', ...options },
    );
  }

  /**
   * Create messages from uploaded files. Files are converted to text and split into
   * multiple messages.
   */
  upload(
    workspaceId: string,
    sessionId: string,
    body: MessageUploadParams,
    options?: Core.RequestOptions,
  ): Core.APIPromise<MessageUploadResponse> {
    return this._client.post(
      `/v2/workspaces/${workspaceId}/sessions/${sessionId}/messages/upload`,
      Core.multipartFormRequestOptions({ body, ...options }),
    );
  }
}

export class MessagesPage extends Page<Message> {}

export interface Message {
  id: string;

  content: string;

  created_at: string;

  peer_id: string;

  session_id: string;

  token_count: number;

  workspace_id: string;

  metadata?: { [key: string]: unknown };
}

export interface MessageCreate {
  content: string;

  peer_id: string;

  created_at?: string | null;

  metadata?: { [key: string]: unknown } | null;
}

export type MessageCreateResponse = Array<Message>;

export type MessageUploadResponse = Array<Message>;

export interface MessageCreateParams {
  messages: Array<MessageCreate>;
}

export interface MessageUpdateParams {
  metadata?: { [key: string]: unknown } | null;
}

export interface MessageListParams extends PageParams {
  /**
   * Query param: Whether to reverse the order of results
   */
  reverse?: boolean | null;

  /**
   * Body param:
   */
  filters?: { [key: string]: unknown } | null;
}

export interface MessageUploadParams {
  file: Core.Uploadable;

  peer_id: string;
}

Messages.MessagesPage = MessagesPage;

export declare namespace Messages {
  export {
    type Message as Message,
    type MessageCreate as MessageCreate,
    type MessageCreateResponse as MessageCreateResponse,
    type MessageUploadResponse as MessageUploadResponse,
    MessagesPage as MessagesPage,
    type MessageCreateParams as MessageCreateParams,
    type MessageUpdateParams as MessageUpdateParams,
    type MessageListParams as MessageListParams,
    type MessageUploadParams as MessageUploadParams,
  };
}
