"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var _Honcho_instances, _a, _Honcho_baseURLOverridden;
Object.defineProperty(exports, "__esModule", { value: true });
exports.UnprocessableEntityError = exports.PermissionDeniedError = exports.InternalServerError = exports.AuthenticationError = exports.BadRequestError = exports.RateLimitError = exports.ConflictError = exports.NotFoundError = exports.APIUserAbortError = exports.APIConnectionTimeoutError = exports.APIConnectionError = exports.APIError = exports.HonchoError = exports.fileFromPath = exports.toFile = exports.Honcho = void 0;
const Core = __importStar(require("./core.js"));
const Errors = __importStar(require("./error.js"));
const Pagination = __importStar(require("./pagination.js"));
const Uploads = __importStar(require("./uploads.js"));
const API = __importStar(require("./resources/index.js"));
const keys_1 = require("./resources/keys.js");
const workspaces_1 = require("./resources/workspaces/workspaces.js");
const environments = {
    demo: 'https://demo.honcho.dev',
    local: 'http://localhost:8000',
    production: 'https://api.honcho.dev',
};
/**
 * API Client for interfacing with the Honcho API.
 */
class Honcho extends Core.APIClient {
    /**
     * API Client for interfacing with the Honcho API.
     *
     * @param {string | null | undefined} [opts.apiKey=process.env['HONCHO_API_KEY'] ?? null]
     * @param {Environment} [opts.environment=demo] - Specifies the environment URL to use for the API.
     * @param {string} [opts.baseURL=process.env['HONCHO_BASE_URL'] ?? https://demo.honcho.dev] - Override the default base URL for the API.
     * @param {number} [opts.timeout=1 minute] - The maximum amount of time (in milliseconds) the client will wait for a response before timing out.
     * @param {number} [opts.httpAgent] - An HTTP agent used to manage HTTP(s) connections.
     * @param {Core.Fetch} [opts.fetch] - Specify a custom `fetch` function implementation.
     * @param {number} [opts.maxRetries=2] - The maximum number of times the client will retry a request.
     * @param {Core.Headers} opts.defaultHeaders - Default headers to include with every request to the API.
     * @param {Core.DefaultQuery} opts.defaultQuery - Default query parameters to include with every request to the API.
     */
    constructor({ baseURL = Core.readEnv('HONCHO_BASE_URL'), apiKey = Core.readEnv('HONCHO_API_KEY') ?? null, ...opts } = {}) {
        const options = {
            apiKey,
            ...opts,
            baseURL,
            environment: opts.environment ?? 'demo',
        };
        if (baseURL && opts.environment) {
            throw new Errors.HonchoError('Ambiguous URL; The `baseURL` option (or HONCHO_BASE_URL env var) and the `environment` option are given. If you want to use the environment you must pass baseURL: null');
        }
        super({
            baseURL: options.baseURL || environments[options.environment || 'demo'],
            baseURLOverridden: baseURL ? baseURL !== environments[options.environment || 'demo'] : false,
            timeout: options.timeout ?? 60000 /* 1 minute */,
            httpAgent: options.httpAgent,
            maxRetries: options.maxRetries,
            fetch: options.fetch,
        });
        _Honcho_instances.add(this);
        this.workspaces = new API.Workspaces(this);
        this.keys = new API.Keys(this);
        this._options = options;
        this.apiKey = apiKey;
    }
    defaultQuery() {
        return this._options.defaultQuery;
    }
    defaultHeaders(opts) {
        return {
            ...super.defaultHeaders(opts),
            ...this._options.defaultHeaders,
        };
    }
    authHeaders(opts) {
        if (this.apiKey == null) {
            return {};
        }
        return { Authorization: `Bearer ${this.apiKey}` };
    }
}
exports.Honcho = Honcho;
_a = Honcho, _Honcho_instances = new WeakSet(), _Honcho_baseURLOverridden = function _Honcho_baseURLOverridden() {
    return this.baseURL !== environments[this._options.environment || 'demo'];
};
Honcho.Honcho = _a;
Honcho.DEFAULT_TIMEOUT = 60000; // 1 minute
Honcho.HonchoError = Errors.HonchoError;
Honcho.APIError = Errors.APIError;
Honcho.APIConnectionError = Errors.APIConnectionError;
Honcho.APIConnectionTimeoutError = Errors.APIConnectionTimeoutError;
Honcho.APIUserAbortError = Errors.APIUserAbortError;
Honcho.NotFoundError = Errors.NotFoundError;
Honcho.ConflictError = Errors.ConflictError;
Honcho.RateLimitError = Errors.RateLimitError;
Honcho.BadRequestError = Errors.BadRequestError;
Honcho.AuthenticationError = Errors.AuthenticationError;
Honcho.InternalServerError = Errors.InternalServerError;
Honcho.PermissionDeniedError = Errors.PermissionDeniedError;
Honcho.UnprocessableEntityError = Errors.UnprocessableEntityError;
Honcho.toFile = Uploads.toFile;
Honcho.fileFromPath = Uploads.fileFromPath;
Honcho.Workspaces = workspaces_1.Workspaces;
Honcho.WorkspacesPage = workspaces_1.WorkspacesPage;
Honcho.Keys = keys_1.Keys;
var uploads_1 = require("./uploads.js");
Object.defineProperty(exports, "toFile", { enumerable: true, get: function () { return uploads_1.toFile; } });
Object.defineProperty(exports, "fileFromPath", { enumerable: true, get: function () { return uploads_1.fileFromPath; } });
var error_1 = require("./error.js");
Object.defineProperty(exports, "HonchoError", { enumerable: true, get: function () { return error_1.HonchoError; } });
Object.defineProperty(exports, "APIError", { enumerable: true, get: function () { return error_1.APIError; } });
Object.defineProperty(exports, "APIConnectionError", { enumerable: true, get: function () { return error_1.APIConnectionError; } });
Object.defineProperty(exports, "APIConnectionTimeoutError", { enumerable: true, get: function () { return error_1.APIConnectionTimeoutError; } });
Object.defineProperty(exports, "APIUserAbortError", { enumerable: true, get: function () { return error_1.APIUserAbortError; } });
Object.defineProperty(exports, "NotFoundError", { enumerable: true, get: function () { return error_1.NotFoundError; } });
Object.defineProperty(exports, "ConflictError", { enumerable: true, get: function () { return error_1.ConflictError; } });
Object.defineProperty(exports, "RateLimitError", { enumerable: true, get: function () { return error_1.RateLimitError; } });
Object.defineProperty(exports, "BadRequestError", { enumerable: true, get: function () { return error_1.BadRequestError; } });
Object.defineProperty(exports, "AuthenticationError", { enumerable: true, get: function () { return error_1.AuthenticationError; } });
Object.defineProperty(exports, "InternalServerError", { enumerable: true, get: function () { return error_1.InternalServerError; } });
Object.defineProperty(exports, "PermissionDeniedError", { enumerable: true, get: function () { return error_1.PermissionDeniedError; } });
Object.defineProperty(exports, "UnprocessableEntityError", { enumerable: true, get: function () { return error_1.UnprocessableEntityError; } });
exports = module.exports = Honcho;
exports.default = Honcho;
//# sourceMappingURL=index.js.map