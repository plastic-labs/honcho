// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
var _Honcho_instances, _a, _Honcho_baseURLOverridden;
import * as Core from "./core.mjs";
import * as Errors from "./error.mjs";
import * as Pagination from "./pagination.mjs";
import * as Uploads from "./uploads.mjs";
import * as API from "./resources/index.mjs";
import { Keys } from "./resources/keys.mjs";
import { Workspaces, WorkspacesPage, } from "./resources/workspaces/workspaces.mjs";
const environments = {
    demo: 'https://demo.honcho.dev',
    local: 'http://localhost:8000',
    production: 'https://api.honcho.dev',
};
/**
 * API Client for interfacing with the Honcho API.
 */
export class Honcho extends Core.APIClient {
    /**
     * API Client for interfacing with the Honcho API.
     *
     * @param {string | null | undefined} [opts.apiKey=process.env['HONCHO_API_KEY'] ?? null]
     * @param {Environment} [opts.environment=demo] - Specifies the environment URL to use for the API.
     * @param {string} [opts.baseURL=process.env['HONCHO_BASE_URL'] ?? https://demo.honcho.dev] - Override the default base URL for the API.
     * @param {number} [opts.timeout=1 minute] - The maximum amount of time (in milliseconds) the client will wait for a response before timing out.
     * @param {number} [opts.httpAgent] - An HTTP agent used to manage HTTP(s) connections.
     * @param {Core.Fetch} [opts.fetch] - Specify a custom `fetch` function implementation.
     * @param {number} [opts.maxRetries=2] - The maximum number of times the client will retry a request.
     * @param {Core.Headers} opts.defaultHeaders - Default headers to include with every request to the API.
     * @param {Core.DefaultQuery} opts.defaultQuery - Default query parameters to include with every request to the API.
     */
    constructor({ baseURL = Core.readEnv('HONCHO_BASE_URL'), apiKey = Core.readEnv('HONCHO_API_KEY') ?? null, ...opts } = {}) {
        const options = {
            apiKey,
            ...opts,
            baseURL,
            environment: opts.environment ?? 'demo',
        };
        if (baseURL && opts.environment) {
            throw new Errors.HonchoError('Ambiguous URL; The `baseURL` option (or HONCHO_BASE_URL env var) and the `environment` option are given. If you want to use the environment you must pass baseURL: null');
        }
        super({
            baseURL: options.baseURL || environments[options.environment || 'demo'],
            baseURLOverridden: baseURL ? baseURL !== environments[options.environment || 'demo'] : false,
            timeout: options.timeout ?? 60000 /* 1 minute */,
            httpAgent: options.httpAgent,
            maxRetries: options.maxRetries,
            fetch: options.fetch,
        });
        _Honcho_instances.add(this);
        this.workspaces = new API.Workspaces(this);
        this.keys = new API.Keys(this);
        this._options = options;
        this.apiKey = apiKey;
    }
    defaultQuery() {
        return this._options.defaultQuery;
    }
    defaultHeaders(opts) {
        return {
            ...super.defaultHeaders(opts),
            ...this._options.defaultHeaders,
        };
    }
    authHeaders(opts) {
        if (this.apiKey == null) {
            return {};
        }
        return { Authorization: `Bearer ${this.apiKey}` };
    }
}
_a = Honcho, _Honcho_instances = new WeakSet(), _Honcho_baseURLOverridden = function _Honcho_baseURLOverridden() {
    return this.baseURL !== environments[this._options.environment || 'demo'];
};
Honcho.Honcho = _a;
Honcho.DEFAULT_TIMEOUT = 60000; // 1 minute
Honcho.HonchoError = Errors.HonchoError;
Honcho.APIError = Errors.APIError;
Honcho.APIConnectionError = Errors.APIConnectionError;
Honcho.APIConnectionTimeoutError = Errors.APIConnectionTimeoutError;
Honcho.APIUserAbortError = Errors.APIUserAbortError;
Honcho.NotFoundError = Errors.NotFoundError;
Honcho.ConflictError = Errors.ConflictError;
Honcho.RateLimitError = Errors.RateLimitError;
Honcho.BadRequestError = Errors.BadRequestError;
Honcho.AuthenticationError = Errors.AuthenticationError;
Honcho.InternalServerError = Errors.InternalServerError;
Honcho.PermissionDeniedError = Errors.PermissionDeniedError;
Honcho.UnprocessableEntityError = Errors.UnprocessableEntityError;
Honcho.toFile = Uploads.toFile;
Honcho.fileFromPath = Uploads.fileFromPath;
Honcho.Workspaces = Workspaces;
Honcho.WorkspacesPage = WorkspacesPage;
Honcho.Keys = Keys;
export { toFile, fileFromPath } from "./uploads.mjs";
export { HonchoError, APIError, APIConnectionError, APIConnectionTimeoutError, APIUserAbortError, NotFoundError, ConflictError, RateLimitError, BadRequestError, AuthenticationError, InternalServerError, PermissionDeniedError, UnprocessableEntityError, } from "./error.mjs";
export default Honcho;
//# sourceMappingURL=index.mjs.map